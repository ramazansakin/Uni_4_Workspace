/* 
 * File:   main.cpp
 * Author: Samet Sait TALAYHAN - CSE241_HW04_101044044
 * 
 *      Gebze Institute of Technology
 *      Department of Computer Engineering
 *      CSE 241/505
 *      Object Oriented Programming
 *      Fall 2012
 * 
 *      Homework 04
 * Created on 03 Kasım 2012 Cumartesi, 13:11
 */

#include <iostream>
#include "Series.h"

using namespace std;

int Series::countObj = 0;

int main(int argc, char** argv) 
{
    Series object(3),object2,object3(1); //create new objects.
    
    object.testClass(object,object2,&object3);

    return 0;
}
