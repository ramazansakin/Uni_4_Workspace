/* 
 * File:   Series.cpp
 * Author: Samet Sait TALAYHAN - CSE241_HW04_101044044
 * 
 *      Gebze Institute of Technology
 *      Department of Computer Engineering
 *      CSE 241/505
 *      Object Oriented Programming
 *      Fall 2012
 * 
 *      Homework 04
 * Created on 04 Kasım 2012 Pazar, 11:36
 */

#include "Series.h"
#include <iostream>
#include <math.h> //for pow().
#include <vector>

using namespace std;

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/*                         Function Implementations                         */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* No-parameter Consturctor Function                                        */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* This consturctor automatically forms a geometric series
 * of k = 0.
*/ 
Series::Series():series(0)
{
    ++countObj;
}

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* One-parameter Consturctor Function                                       */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* This consturctor accepts the limit k and forms the series
 * automatically.
*/ 
Series::Series(int limitK)
{
    for(int i=0;i<limitK;++i)
    {
        series.push_back(get(i));
    }
    ++countObj;
}

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Function get                                                             */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* This function is getter. Getter for the series elements,
 * for example get(5), returns a5.
/* 
/*  RETURN VALUE
/*  Return value of series element. 
/*  */
double Series::get(int limitK) const
{
    return 1/pow(2.,double(limitK));
}

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Function getCountObj                                                     */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* This function is getter. Getter for number of series objects alive.
/* 
/*  RETURN VALUE
/*  Return number of series object alive. 
/*  */
int Series::getCounObj() const
{
    return countObj;
}

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Function getSeries                                                       */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* This function is getter. Getter for the series elements,
 * for example get(5), returns a5.
/* 
/*  RETURN VALUE
/*  Return value of series element. 
/*  */
vector<double> Series::getSeries() const 
{
    return series;
}

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Function evaluate                                                        */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* This function is mutator that evaluates the series and returns the 
 * result.                         
/* 
/*  RETURN VALUE
/*  Return value of series. 
/*  */
double Series::evaluate()
{
    double result=0;
    for(int i=0;i<series.size();++i)
    {
        result +=  1/pow(2.0,double(i));
    }
    
    return result;
}

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Function add()                                                           */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* This function adds just one series element to the end of the series.                        
*/
void Series::add()
{
    series.push_back(get(series.size()+1));
    //adds just one series element to the end of the series.
}

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Function remove()                                                        */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* This function removes just one series element to the end of the series.                        
*/
void Series::remove()
{
    series.pop_back();
    //removes just one series element to the end of the series.
}

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Function mult()                                                          */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* This function multiplies each lement in the series with the given double
 * which is given as a function parameter.
 * 
*/
void Series::mult(double num)
{
    for(int i=0;i<series.size();++i)
    {
        series[i] *= num;
    }
}

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Function print()                                                         */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* This function prints the series elements to the screen.                                
*/
void Series::print()const
{
    cout<<"Geometric Series Members"<<endl;
    cout<<"------------------------"<<endl;
    for(int i=0;i<series.size();++i)
    {
        cout<<"Series a"<<i<<" = "<<series[i]<<endl;
    }
}

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Function predicate()                                                     */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Predicate function returns true if the series is empty.                                
*/
/*  RETURN VALUE
/*  Return value type is boolean,
/*  */
bool Series::predicate() const
{
    if(series.size()==0)
        return true;
    else
        return false;
}
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Function comparison()                                                    */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/*Comparison function takes another series object as parameter
/*and returns true if the other series evaluates to a larger number.                              
 * 
/*  RETURN VALUE
/*  Return value type is boolean,
/*  */
bool Series::comparison(Series newObject) const
{
    if(newObject.getSeries().size()>series.size())
        return true;
    else
        return false;
}

/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* Function testClass ()                                                    */
/***************************************************************************­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­*/
/* This function tests the class.
 * 
 */

void Series::testClass(Series testObje, 
                 const Series &testObje2, 
                       Series *testObje3)
{
    testObje.print();
    cout<<endl;
    cout<<"Test Predicate Function :"<<testObje2.predicate()<<endl;
    
    testObje3->print();
    cout<<"\nAdded a new element."<<endl;
    testObje3->add();
    cout<<endl;
    testObje3->print();
    
    cout<<"\n************************"<<endl;
    
    testObje3->print();
    cout<<endl;
    cout<<"Test Comparison Function :"<<testObje2.comparison(testObje)<<endl;
    
    cout<<"\n************************"<<endl;
    
    testObje.add();
    cout<<"\nAdded a new element."<<endl;
    testObje.print();
    testObje.add();
    cout<<"\nAdded a new element."<<endl;
    testObje.print();
    testObje.remove();
    cout<<"\nRemoved one element."<<endl;
    testObje.print();
    
    cout<<endl;
    cout<<"\n************************"<<endl;
    cout<<"Multiply the series with 2:"<<endl;
    testObje.mult(2);
    testObje.print();
    
    cout<<endl;
    cout<<"\n************************"<<endl;
    cout<<"Test CountObject Function:  "<<testObje2.getCounObj()<<endl;
    
}
