/* 
 * File:   Series.h
 * Author: Samet Sait TALAYHAN - CSE241_HW04_101044044
 * 
 *      Gebze Institute of Technology
 *      Department of Computer Engineering
 *      CSE 241/505
 *      Object Oriented Programming
 *      Fall 2012
 * 
 *      Homework 04
 * Created on 04 Kasım 2012 Pazar, 11:36
 */

#ifndef SERIES_H
#define	SERIES_H

#include <vector>

using namespace std;

class Series
{
public:
    Series(); //Non-parameter constructor.
    //Initializes the k to 0.
    
    Series(int limitK);//One-parameter constructor.
    //Initializes the k to limitK.
    
    double get(int limitK)const;
    //get function returns the value of k.
    vector<double> getSeries() const;

    int getCounObj() const;
    
    double evaluate();
    //Evaluate the series and returns the result.
    void add();
    //Add function adds just one series element to the end of the series.
    void remove();
    //Remove function that removes just one element to the end of the series.
    void mult(double num);
    //Mult Function that multiplies each element
    void print() const;
    //Print Function that prints the series elements to the screen
    bool predicate() const;
    //Predicate function returns true if the series is empty.
    bool comparison(Series newObject) const;
    //Comparison function takes another series object as parameter
    //and returns true if the other series evaluates to a larger number.
    void testClass(Series testObje,
             const Series &testObje2, 
                   Series *testObje3);
    
private:
    vector<double> series;
    static int countObj;
    
};

#endif	/* SERIES_H */

