/*
*--------------------------------
* CSE222_HW07_101044044
*--------------------------------
* @author Samet Sait Talayhan
*/
package binarysearchtree;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class BinarySearchTreeTest {
    
    public BinarySearchTreeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of add method, of class BinarySearchTree.
     */
    @Test
    public void testAdd() {
        System.out.println("add Integer");
        Integer item = 15;
        BinarySearchTree instance = new BinarySearchTree();
        boolean expResult = true;
        boolean result = instance.add(item);
        assertEquals(expResult, result);
        
        System.out.println("add Double");
        Double item2 = 5.2;
        BinarySearchTree instance2 = new BinarySearchTree();
        boolean expResult2 = true;
        boolean result2 = instance2.add(item2);
        assertEquals(expResult2, result2);
        
        System.out.println("add String");
        String item3 = "Deneme";
        BinarySearchTree instance3 = new BinarySearchTree();
        boolean expResult3 = true;
        boolean result3 = instance3.add(item3);
        assertEquals(expResult3, result3);
        
        
        
    }

    /**
     * Test of contains method, of class BinarySearchTree.
     */
    @Test
    public void testContains() {
        System.out.println("contains");
        Integer target = 15;
        BinarySearchTree instance = new BinarySearchTree();
        boolean expResult = false;
        boolean result = instance.contains(target);
        assertEquals(expResult, result);
        
        System.out.println("contains");
        Double target2 = 15.2;
        BinarySearchTree instance2 = new BinarySearchTree();
        boolean expResult2 = false;
        boolean result2 = instance2.contains(target);
        assertEquals(expResult2, result2);
        
        System.out.println("contains");
        String target3 = "Deneme";
        BinarySearchTree instance3 = new BinarySearchTree();
        boolean expResult3 = false;
        boolean result3 = instance3.contains(target3);
        assertEquals(expResult3, result3);
    }

    /**
     * Test of find method, of class BinarySearchTree.
     */
    @Test
    public void testFind() {
        System.out.println("find");
        Integer target = null;
        BinarySearchTree instance = new BinarySearchTree();
        Object expResult = null;
        Object result = instance.find(target);
        assertEquals(expResult, result);
        
        System.out.println("find");
        Double target2 = null;
        BinarySearchTree instance2 = new BinarySearchTree();
        Object expResult2 = null;
        Object result2 = instance2.find(target2);
        assertEquals(expResult2, result2);
        
        System.out.println("find");
        String target3 = null;
        BinarySearchTree instance3 = new BinarySearchTree();
        Object expResult3 = null;
        Object result3 = instance3.find(target3);
        assertEquals(expResult3, result3);
    }

    /**
     * Test of delete method, of class BinarySearchTree.
     */
    @Test
    public void testDelete() {
        System.out.println("delete");
        Integer target = 15;
        BinarySearchTree instance = new BinarySearchTree();
        Object expResult = null;
        Object result = instance.delete(target);
        assertEquals(expResult, result);
        
        System.out.println("delete");
        Double target2 = 15.4;
        BinarySearchTree instance2 = new BinarySearchTree();
        Object expResult2 = null;
        Object result2 = instance2.delete(target2);
        assertEquals(expResult2, result2);
        
        System.out.println("delete");
        String target3 = "Deneme";
        BinarySearchTree instance3 = new BinarySearchTree();
        Object expResult3 = null;
        Object result3 = instance3.delete(target3);
        assertEquals(expResult3, result3);
    }

    /**
     * Test of remove method, of class BinarySearchTree.
     */
    @Test
    public void testRemove() {
        System.out.println("remove");
        Integer target = 15;
        BinarySearchTree instance = new BinarySearchTree();
        instance.add(target);
        boolean expResult = true;
        boolean result = instance.remove(target);
        assertEquals(expResult, result);
        
        System.out.println("remove");
        Double target2 = 15.2;
        BinarySearchTree instance2 = new BinarySearchTree();
        instance2.add(target2);
        boolean expResult2 = true;
        boolean result2 = instance2.remove(target2);
        assertEquals(expResult2, result2);
        
        System.out.println("remove");
        String target3 = "Deneme";
        BinarySearchTree instance3 = new BinarySearchTree();
        instance3.add(target3);
        boolean expResult3 = true;
        boolean result3 = instance3.remove(target3);
        assertEquals(expResult3, result3);
    }
}