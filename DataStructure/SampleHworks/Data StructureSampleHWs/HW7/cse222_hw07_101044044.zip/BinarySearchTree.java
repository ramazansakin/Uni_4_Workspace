/*
*--------------------------------
* CSE222_HW07_101044044
*--------------------------------
* @author Samet Sait Talayhan
*/
package binarysearchtree;

import java.lang.reflect.Array;


public class BinarySearchTree < E
    extends Comparable < E >>
    implements SearchTree < E > {

    private static final int INITIAL_CAPACITY = 16;
    /**
     * Data Fields
     */
    private E[] myArray;
    /**
     * The current capacity of the array
     */
    private int capacity = 0;
    /**
     * The current size of the array (number of directory entries)
     */
    private int size = 0;
    /**
     * Return value from the public add method.
     */
    private boolean addReturn;
    /**
     * Return value from the public delete method.
     */
    private E deleteReturn;

    public BinarySearchTree() {
        capacity = INITIAL_CAPACITY;  
        myArray = (E[])Array.newInstance(Comparable.class, capacity);
    }
    
    @Override
    public boolean add(E item) {
        //Check array capacity,
        if(size*4 >= capacity){
            reallocate();
        }
        add(myArray, item, 1);
        //if adReturn is true, increase size.
        if(addReturn == true){
            size++;
        }
        return addReturn;
    }
    
    /**
     * Recurisve add method
     */
    private void add(E[] localRoot, E item, int rootNumb)
    {
        rootNumb = rootNumb - 1;
        if(localRoot[rootNumb] == null)
        {
            //item is not in the tree - insert it
            addReturn = true;
            localRoot[rootNumb] = item;
        }
        else if( item.compareTo(localRoot[rootNumb]) == 0 )
        {
            //item is equal to localRoot[rootNumb]
            addReturn = false;
        }
        else if( item.compareTo(localRoot[rootNumb]) < 0 )
        {
            //item is less than localRoot
            rootNumb = rootNumb + 1;
            add(localRoot, item, rootNumb*2);
        }
        else
        {
            //item is greater than localRoot
            rootNumb = rootNumb + 1;
            add(localRoot, item, (rootNumb*2)+1 );
        }
    }

    @Override
    public boolean contains(E target) {
        return find(target) != null;
    }

    @Override
    public E find(E target) {
        return find(myArray, target, 1);
    }
    /**
     * Recursive Find method.
     */
    private E find(E[] localRoot, E target, int rootNumb)
    {
        rootNumb = rootNumb -1;
        if(localRoot[rootNumb] == null)
        {
            return null;
        }
        
        //Compare the target with the data field at the root.
        int compResult = target.compareTo(localRoot[rootNumb]);
        if(compResult == 0)
            return localRoot[rootNumb];
        else if(compResult < 0)
        {
            rootNumb = rootNumb + 1;
            return find(localRoot,target,rootNumb*2);
        }
        else
        {
            rootNumb = rootNumb + 1;
            return find(localRoot, target, (rootNumb*2) + 1);
        }
    }
    
    @Override
    public E delete(E target) {
        if(myArray[0] == null)
        {
            //item is not in the tree.
            deleteReturn = null;
        }
        else{
            delete(myArray, target, 1);
        }
        
        if(deleteReturn != null)
            --size;
        
        return deleteReturn;
    }
    /** Recursive delete method.
     * 
     * @param target
     * @return 
     */
    private void delete(E[] localRoot, E item, int rootNumb)
    {
        //Search for item to delete.
        int compResult = item.compareTo(localRoot[rootNumb-1]);
        if (compResult < 0) {
            // item is smaller than localRoot.data.
            // go left child.
            delete(localRoot, item,rootNumb*2);
        }
        else if (compResult > 0) {
            // item is larger than localRoot.data.
            // go right child.
            delete(localRoot, item, (rootNumb*2)+1 );
        }
        else {
            // item is at local root.
            deleteReturn = localRoot[rootNumb-1];
            int checkLeftChild = (rootNumb * 2);
            int checkRightChild = checkLeftChild + 1;
            if (localRoot[checkLeftChild - 1] == null) { 
                // If there is no left child, return right child
                // which can also be null.
                localRoot[rootNumb - 1] = localRoot[checkRightChild - 1];
                //Eger 2 cocuguda yoksa null ata..
                if( localRoot[checkRightChild*2 -1 ] == null && localRoot[checkRightChild*2+1-1] == null ){
                    localRoot[checkLeftChild-1] = null;
                }
                else
                    delete(localRoot, localRoot[checkRightChild-1], checkRightChild);

            }
            else if (localRoot[checkRightChild - 1] == null) {
                // If there is no right child, return left child.
                localRoot[rootNumb-1] = localRoot[checkLeftChild-1];
                //Eger sol cocugun 2 cocuguda yoksa null ata.
                if( localRoot[checkLeftChild*2 -1 ] == null && localRoot[checkLeftChild*2+1-1] == null ){
                    localRoot[checkLeftChild-1] = null;
                }
                else
                    delete(localRoot, localRoot[checkLeftChild-1], checkLeftChild);
                
            }
            else { // 2 children
                // Node being deleted has 2 children, replace the data
                // with inorder predecessor.
                if (localRoot[checkLeftChild*2+1-1] == null) {
                    // The left child has no right child.
                    // Replace the data with the data in the
                    // left child.
                    localRoot[rootNumb-1] = localRoot[checkLeftChild-1];
                    //Eger sol cocugun 2 cocuguda yoksa null ata..
                    if( localRoot[checkLeftChild*2 -1 ] == null && localRoot[checkLeftChild*2+1-1] == null ){
                        localRoot[checkLeftChild-1] = null;
                    }
                    else
                        delete(localRoot, localRoot[checkLeftChild-1], checkLeftChild);
                } else {
                    // Search for the inorder predecessor (ip) and
                    // replace deleted node’s data with ip.
                    if ( localRoot[(checkLeftChild*2+1)*2+1-1] == null ) {
                       localRoot[rootNumb-1] = localRoot[checkLeftChild*2+1-1];
                       delete(localRoot, localRoot[checkLeftChild*2+1-1],checkLeftChild*2 ); 
                    }
                }
            }
        }
    }

    @Override
    public boolean remove(E target) {
        return delete(target) != null;
    }

    @Override
    public int maxDepth() {
        //To change body of generated methods, choose Tools | Templates.
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
    /**
     * Allocate a new array to hold the elements.
     */
    private void reallocate() {
        capacity = 2 * capacity;
        E[] newData;
        newData = (E[])Array.newInstance(Comparable.class, capacity);
        System.arraycopy(myArray, 0, newData, 0, size);
        myArray = newData;
    }
}
